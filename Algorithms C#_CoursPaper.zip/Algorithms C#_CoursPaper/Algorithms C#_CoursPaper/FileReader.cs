﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Класс для чтения данных из файла
public class FileReader
{
    public static List<Request> ReadRequests(string filePath)
    {
        var requests = new List<Request>();
        var lines = File.ReadAllLines(filePath);

        Request currentRequest = null;
        Teacher currentTeacher = null;

        foreach (var line in lines)
        {
            if (string.IsNullOrWhiteSpace(line))
                continue;

            if (line.Contains(":") && !line.Contains("-"))
            {
                var parts = line.Split(':');
                var teacherNameParts = parts[0].Trim().Split(' ');

                currentTeacher = new Teacher
                {
                    First_name = teacherNameParts[1],
                    Last_name = teacherNameParts[0],
                    Patronymic = teacherNameParts.Length > 2 ? teacherNameParts[2] : string.Empty
                };
            }
            else if (line.Contains("-"))
            {
                var parts = line.Split('-');
                var timeParts = parts[0].Trim().Split(' ');
                var auditoriumParts = parts[1].Trim().Split(',');

                var classTime = new ClassTime
                {
                    StartLesson = DateTime.ParseExact(timeParts[0].Trim(), "HH:mm", null),
                    EndLesson = DateTime.ParseExact(timeParts[1].Trim(), "HH:mm", null)
                };

                var pavilions = auditoriumParts.Select(a => new Pavilion { Auditorium = int.Parse(a.Trim()) }).ToList();

                foreach (var pavilion in pavilions)
                {
                    var existingRequest = requests
                        .FirstOrDefault(r => r.PreferredTimes.StartLesson == classTime.StartLesson &&
                                             r.PreferredTimes.EndLesson == classTime.EndLesson &&
                                             r.PreferredAuditoriums.Auditorium == pavilion.Auditorium);

                    if (existingRequest != null)
                    {
                        // Добавляем преподавателя к существующему запросу
                        existingRequest.Teachers.Add(currentTeacher);
                    }
                    else
                    {
                        // Создаем новый запрос
                        currentRequest = new Request
                        {
                            Teachers = new List<Teacher> { currentTeacher },
                            PreferredTimes = classTime,
                            PreferredAuditoriums = pavilion
                        };

                        requests.Add(currentRequest);
                    }
                }
            }
            else
            {
                requests = null;
                break;
            }
        }

        return requests;
    }
}