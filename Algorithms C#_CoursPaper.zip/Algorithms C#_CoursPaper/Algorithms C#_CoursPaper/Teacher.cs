﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Teacher
{
    public int Id { get; set; }
    public string First_name { get; set; }
    public string Last_name { get; set; }
    public string Patronymic { get; set; }
    public string FullName
    {
        get { return $"{Last_name} {First_name} {Patronymic}"; }
    }
}