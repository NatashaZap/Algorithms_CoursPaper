﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms_C__CoursPaper
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var filePath = "C:\\Users\\natas\\source\\repos\\Algorithms C#_CoursPaper\\Algorithms C#_CoursPaper\\schedule_data.txt";
            var requests = FileReader.ReadRequests(filePath);
            //foreach (var request in requests)
            //{
            //    foreach (var teacher in request.Teachers)
            //    {
            //        Console.WriteLine($"Teacher: {teacher.FullName}");
            //    }

            //    Console.WriteLine($"Time: {request.PreferredTimes.StartLesson:HH:mm} - {request.PreferredTimes.EndLesson:HH:mm}, Auditorium: {request.PreferredAuditoriums.Auditorium}");
            //    Console.WriteLine();
            //}
            //Console.ReadLine();
            if (requests != null)
            {
                var allocations = AuditoriumAllocator.AllocateAuditoriums(requests);

                foreach (var teacherAllocation in allocations)
                {
                    Console.WriteLine($"Teacher: {teacherAllocation.Key.FullName}");
                    foreach (var allocation in teacherAllocation.Value)
                    {
                        Console.WriteLine($"Time: {allocation.Key.StartLesson:HH:mm} - {allocation.Key.EndLesson:HH:mm}, Auditorium: {allocation.Value.Auditorium}");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Ошибка чтения файла");
            }
            Console.ReadLine();
        }
    }
}
