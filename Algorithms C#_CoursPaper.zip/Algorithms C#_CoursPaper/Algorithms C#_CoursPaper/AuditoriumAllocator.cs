﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Класс для распределения аудиторий
public class AuditoriumAllocator
{
    public static Dictionary<Teacher, Dictionary<ClassTime, Pavilion>> AllocateAuditoriums(List<Request> requests)
    {
        var allocations = new Dictionary<Teacher, Dictionary<ClassTime, Pavilion>>();
        var usedAuditoriums = new Dictionary<ClassTime, HashSet<Pavilion>>();
        var teacherClaimCounts = new Dictionary<Teacher, int>();

        foreach (var request in requests)
        {
            var teachers = request.Teachers;
            var time = request.PreferredTimes;
            var auditorium = request.PreferredAuditoriums;

            if (!usedAuditoriums.ContainsKey(time))
            {
                usedAuditoriums[time] = new HashSet<Pavilion>();
            }

            foreach (var teacher in teachers)
            {
                if (!allocations.ContainsKey(teacher))
                {
                    allocations[teacher] = new Dictionary<ClassTime, Pavilion>();
                }

                if (!allocations[teacher].ContainsKey(time) && !usedAuditoriums[time].Contains(auditorium))
                {
                    allocations[teacher][time] = auditorium;
                    usedAuditoriums[time].Add(auditorium);
                    teacherClaimCounts[teacher] = teacherClaimCounts.ContainsKey(teacher) ? teacherClaimCounts[teacher] + 1 : 1;
                }
                else if (!allocations[teacher].ContainsKey(time))
                {
                    // Поиск другой свободной аудитории в желаемое время
                    var availableAuditorium = FindAvailableAuditorium(usedAuditoriums, time, requests);
                    if (availableAuditorium != null)
                    {
                        allocations[teacher][time] = availableAuditorium;
                        usedAuditoriums[time].Add(availableAuditorium);
                        teacherClaimCounts[teacher] = teacherClaimCounts.ContainsKey(teacher) ? teacherClaimCounts[teacher] + 1 : 1;
                    }
                    else
                    {
                        // Если нет доступных аудиторий, назначаем аудиторию -1
                        allocations[teacher][time] = new Pavilion { Auditorium = -1 };
                    }
                }
            }
        }

        // Проверка на то, что один преподаватель занял только одну аудиторию в данное время и перераспределение при необходимости
        foreach (var allocation in allocations.ToList())
        {
            var teacher = allocation.Key;
            var times = allocation.Value.Keys.ToList();

            foreach (var time in times)
            {
                var allocatedAuditorium = allocation.Value[time];
                var otherAllocations = allocations.Where(a => a.Key != teacher && a.Value.ContainsKey(time) && a.Value[time] == allocatedAuditorium).ToList();

                foreach (var otherAllocation in otherAllocations)
                {
                    var otherTeacher = otherAllocation.Key;
                    var candidates = requests.Where(r => r.PreferredTimes == time && r.Teachers.Contains(otherTeacher) && !usedAuditoriums[time].Contains(r.PreferredAuditoriums))
                                             .OrderBy(r => teacherClaimCounts.ContainsKey(r.Teachers.First()) ? teacherClaimCounts[r.Teachers.First()] : 0)
                                             .ToList();

                    if (candidates.Count > 0)
                    {
                        var candidate = candidates.First();
                        allocations[otherTeacher][time] = candidate.PreferredAuditoriums;
                        usedAuditoriums[time].Remove(allocatedAuditorium);
                        usedAuditoriums[time].Add(candidate.PreferredAuditoriums);
                    }
                    else
                    {
                        allocations[otherTeacher].Remove(time);
                        usedAuditoriums[time].Remove(allocatedAuditorium);

                        // Назначение другой свободной аудитории или аудитории -1
                        var newAuditorium = FindAvailableAuditorium(usedAuditoriums, time, requests);
                        if (newAuditorium != null)
                        {
                            allocations[otherTeacher][time] = newAuditorium;
                            usedAuditoriums[time].Add(newAuditorium);
                        }
                        else
                        {
                            allocations[otherTeacher][time] = new Pavilion { Auditorium = -1 };
                        }
                    }
                }
            }
        }

        return allocations;
    }

    private static Pavilion FindAvailableAuditorium(Dictionary<ClassTime, HashSet<Pavilion>> usedAuditoriums, ClassTime time, List<Request> requests)
    {
        var allAuditoriums = requests.Select(r => r.PreferredAuditoriums).Distinct().ToList();
        foreach (var auditorium in allAuditoriums)
        {
            if (!usedAuditoriums[time].Contains(auditorium))
            {
                return auditorium;
            }
        }
        return null;
    }
}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//// Класс для распределения аудиторий
//public class AuditoriumAllocator
//{
//    public static Dictionary<Teacher, Dictionary<ClassTime, Pavilion>> AllocateAuditoriums(List<Request> requests)
//    {
//        var allocations = new Dictionary<Teacher, Dictionary<ClassTime, Pavilion>>();
//        var usedAuditoriums = new Dictionary<ClassTime, HashSet<Pavilion>>();
//        var teacherClaimCounts = new Dictionary<Teacher, int>();

//        foreach (var request in requests)
//        {
//            var teachers = request.Teachers;
//            var time = request.PreferredTimes;
//            var auditorium = request.PreferredAuditoriums;

//            if (!usedAuditoriums.ContainsKey(time))
//            {
//                usedAuditoriums[time] = new HashSet<Pavilion>();
//            }

//            foreach (var teacher in teachers)
//            {
//                if (!allocations.ContainsKey(teacher))
//                {
//                    allocations[teacher] = new Dictionary<ClassTime, Pavilion>();
//                }

//                if (!allocations[teacher].ContainsKey(time) && !usedAuditoriums[time].Contains(auditorium))
//                {
//                    allocations[teacher][time] = auditorium;
//                    usedAuditoriums[time].Add(auditorium);
//                    teacherClaimCounts[teacher] = teacherClaimCounts.ContainsKey(teacher) ? teacherClaimCounts[teacher] + 1 : 1;
//                }
//                else if (!allocations[teacher].ContainsKey(time))
//                {
//                    // Поиск другой свободной аудитории в желаемое время
//                    var availableAuditorium = FindAvailableAuditorium(usedAuditoriums, time, requests);
//                    if (availableAuditorium != null)
//                    {
//                        allocations[teacher][time] = availableAuditorium;
//                        usedAuditoriums[time].Add(availableAuditorium);
//                        teacherClaimCounts[teacher] = teacherClaimCounts.ContainsKey(teacher) ? teacherClaimCounts[teacher] + 1 : 1;
//                    }
//                }
//            }
//        }

//        // Проверка на то, что один преподаватель занял только одну аудиторию в данное время и перераспределение при необходимости
//        foreach (var allocation in allocations.ToList())
//        {
//            var teacher = allocation.Key;
//            var times = allocation.Value.Keys.ToList();

//            foreach (var time in times)
//            {
//                var allocatedAuditorium = allocation.Value[time];
//                var otherAllocations = allocations.Where(a => a.Key != teacher && a.Value.ContainsKey(time) && a.Value[time] == allocatedAuditorium).ToList();

//                foreach (var otherAllocation in otherAllocations)
//                {
//                    var otherTeacher = otherAllocation.Key;
//                    var candidates = requests.Where(r => r.PreferredTimes == time && r.Teachers.Contains(otherTeacher) && !usedAuditoriums[time].Contains(r.PreferredAuditoriums))
//                                             .OrderBy(r => teacherClaimCounts.ContainsKey(r.Teachers.First()) ? teacherClaimCounts[r.Teachers.First()] : 0)
//                                             .ToList();

//                    if (candidates.Count > 0)
//                    {
//                        var candidate = candidates.First();
//                        allocations[otherTeacher][time] = candidate.PreferredAuditoriums;
//                        usedAuditoriums[time].Remove(allocatedAuditorium);
//                        usedAuditoriums[time].Add(candidate.PreferredAuditoriums);
//                    }
//                    else
//                    {
//                        allocations[otherTeacher].Remove(time);
//                        usedAuditoriums[time].Remove(allocatedAuditorium);

//                        // Назначение другой свободной аудитории
//                        var newAuditorium = FindAvailableAuditorium(usedAuditoriums, time, requests);
//                        if (newAuditorium != null)
//                        {
//                            allocations[otherTeacher][time] = newAuditorium;
//                            usedAuditoriums[time].Add(newAuditorium);
//                        }
//                    }
//                }
//            }
//        }

//        return allocations;
//    }

//    private static Pavilion FindAvailableAuditorium(Dictionary<ClassTime, HashSet<Pavilion>> usedAuditoriums, ClassTime time, List<Request> requests)
//    {
//        var allAuditoriums = requests.Select(r => r.PreferredAuditoriums).Distinct().ToList();
//        foreach (var auditorium in allAuditoriums)
//        {
//            if (!usedAuditoriums[time].Contains(auditorium))
//            {
//                return auditorium;
//            }
//        }
//        return null;
//    }
//}

//public class AuditoriumAllocator
//{
//    public static Dictionary<Teacher, Dictionary<ClassTime, Pavilion>> AllocateAuditoriums(List<Request> requests)
//    {
//        var allocations = new Dictionary<Teacher, Dictionary<ClassTime, Pavilion>>();
//        var usedAuditoriums = new Dictionary<ClassTime, HashSet<Pavilion>>();
//        var teacherClaimCounts = new Dictionary<Teacher, int>();

//        foreach (var request in requests)
//        {
//            var teachers = request.Teachers;
//            var time = request.PreferredTimes;
//            var auditorium = request.PreferredAuditoriums;

//            if (!usedAuditoriums.ContainsKey(time))
//            {
//                usedAuditoriums[time] = new HashSet<Pavilion>();
//            }

//            foreach (var teacher in teachers)
//            {
//                if (!allocations.ContainsKey(teacher))
//                {
//                    allocations[teacher] = new Dictionary<ClassTime, Pavilion>();
//                }

//                if (!allocations[teacher].ContainsKey(time) && !usedAuditoriums[time].Contains(auditorium))
//                {
//                    allocations[teacher][time] = auditorium;
//                    usedAuditoriums[time].Add(auditorium);
//                    teacherClaimCounts[teacher] = teacherClaimCounts.ContainsKey(teacher) ? teacherClaimCounts[teacher] + 1 : 1;
//                    break;
//                }
//            }
//        }

//        // Проверка на то, что один преподаватель занял только одну аудиторию в данное время и перераспределение при необходимости
//        foreach (var allocation in allocations.ToList())
//        {
//            var teacher = allocation.Key;
//            var times = allocation.Value.Keys.ToList();

//            foreach (var time in times)
//            {
//                var allocatedAuditorium = allocation.Value[time];
//                var otherAllocations = allocations.Where(a => a.Key != teacher && a.Value.ContainsKey(time) && a.Value[time] == allocatedAuditorium).ToList();

//                foreach (var otherAllocation in otherAllocations)
//                {
//                    var otherTeacher = otherAllocation.Key;

//                    var candidates = requests.Where(r => r.PreferredTimes == time && r.Teachers.Contains(otherTeacher) && !usedAuditoriums[time].Contains(r.PreferredAuditoriums))
//                                             .OrderBy(r => teacherClaimCounts.ContainsKey(r.Teachers.First()) ? teacherClaimCounts[r.Teachers.First()] : 0)
//                                             .ToList();

//                    if (candidates.Count > 0)
//                    {
//                        var candidate = candidates.First();
//                        allocations[otherTeacher][time] = candidate.PreferredAuditoriums;
//                        usedAuditoriums[time].Remove(allocatedAuditorium);
//                        usedAuditoriums[time].Add(candidate.PreferredAuditoriums);
//                    }
//                    else
//                    {
//                        allocations[otherTeacher].Remove(time);
//                        usedAuditoriums[time].Remove(allocatedAuditorium);
//                    }
//                }
//            }
//        }

//        return allocations;
//    }
//}