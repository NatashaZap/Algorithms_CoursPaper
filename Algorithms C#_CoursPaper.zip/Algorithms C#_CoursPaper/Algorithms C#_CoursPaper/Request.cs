﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Request
{
    public List<Teacher> Teachers { get; set; }
    public ClassTime PreferredTimes { get; set; }
    public Pavilion PreferredAuditoriums { get; set; }
}
